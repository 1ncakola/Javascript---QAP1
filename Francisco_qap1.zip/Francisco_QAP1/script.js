function changeBackground(color) {
    document.body.style.background = color;
 }
 
 window.addEventListener("load",function() { changeBackground('beige') });


 function demoFunc() {
   let txt = document.getElementById("demo");
   txt.style.textAlign = "justify";
 }

 function mainTittleFunc() {
    let txt = document.getElementById("maintitle")
    txt.style.textAlign = "center";
 }

